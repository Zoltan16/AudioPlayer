﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace AudioLejatszo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BindingList<string> _playlist = new BindingList<string>();
        MediaPlayer _mediaPlayer = new MediaPlayer();
        DispatcherTimer _mediaPlayerTimer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            Lista.ItemsSource = _playlist;
            _mediaPlayer.MediaOpened += _mediaPlayer_MediaOpened;
            _mediaPlayer.MediaEnded += _mediaPlayer_MediaEnded;
        }

        private void _mediaPlayer_MediaOpened(object sender, EventArgs e)
        {
            if (_mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                Csúszka.Maximum = _mediaPlayer.NaturalDuration.TimeSpan.TotalMilliseconds;
                _mediaPlayerTimer.Interval = TimeSpan.FromMilliseconds(200);
                _mediaPlayerTimer.Tick += UpdateTime;
                _mediaPlayerTimer.Start();
            }
        }

        void UpdateTime(object sender, EventArgs e)
        {
            Csúszka.Value = _mediaPlayer.Position.TotalMilliseconds;
            if (_mediaPlayer.NaturalDuration.HasTimeSpan && !_mediaPlayer.IsMuted)
                Idő.Text = $"{_mediaPlayer.Position.ToString(@"m\:ss")}/{_mediaPlayer.NaturalDuration.TimeSpan.ToString(@"m\:ss")}";
            else
                Idő.Text = "0:00/0:00";
        }



        private void _mediaPlayer_MediaEnded(object sender, EventArgs e)
        {
            if (Lista.SelectedIndex == -1) return;

            Lista.SelectedIndex++;
            if (Lista.SelectedIndex != Lista.Items.Count - 1)
            {
                PlayCurrentSong();
            }
            else
            {
                Pause();
                Lista.SelectedIndex = -1;
                _mediaPlayer.Stop();
            }
        }

        private void Mappa_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog()
            {
                Multiselect = true,
                Filter = "Audio Files (*.mp3; *.flac; *.wav) |*.mp3;*.flac;*.wav"
            };

            if ((bool)fileDialog.ShowDialog())
            {
                fileDialog.FileNames.ToList().ForEach(x =>
                {
                    _playlist.Add(x);
                });
                Lista.SelectedIndex = 0;

            }
        }

        private void PlayStop_Click(object sender, RoutedEventArgs e)
        {
            if ((string)Lejátszás.Content == "Lejátszás" && _playlist.Count != 0)
            {
                Play();
            }
            else if ((string)Lejátszás.Content == "Megállítás")
            {
                Pause();
            }
        }

        private void Lista_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (Lista.SelectedIndex == -1) return;
            try
            {
                PlayCurrentSong();
            }
            catch (Exception)
            {
                MessageBox.Show("Nem lehet lejátszani a kiválasztott fájlt!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        void Play()
        {
            if (Lista.SelectedIndex == -1) return;

            Lejátszás.Content = "Megállítás";
            _mediaPlayer.Play();
        }

        void Pause()
        {
            Lejátszás.Content = "Lejátszás";
            _mediaPlayer.Pause();
        }

        void PlayCurrentSong()
        {
            _mediaPlayer.Open(new Uri((string)Lista.SelectedItem));
            Play();
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            Pause();
            Lista.SelectedIndex = -1;
            _mediaPlayer.Stop();
        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != 0)
                Lista.SelectedIndex--;
            PlayCurrentSong();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != Lista.Items.Count - 1)
                Lista.SelectedIndex++;
            PlayCurrentSong();
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _mediaPlayer.Volume = e.NewValue;
        }

        private void Ment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lejatszasilista.Items.Clear();
                for (int i = 0; i < Lista.Items.Count; i++)
                {
                    Lejatszasilista.Items.Add(Lista.Items[i].ToString());
                }
            }
            catch (Exception o)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void Csúszka_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _mediaPlayer.Position = TimeSpan.FromMilliseconds(e.NewValue);
        }

        private void Törlés_Click(object sender, RoutedEventArgs e)
        {
            if (Lista != null)
            {
                try
                {
                    if (Lista.SelectedIndex != -1)
                        _playlist.RemoveAt(Lista.SelectedIndex);

                    Stop_Click(null, null);
                }
                catch (Exception o)
                {
                    MessageBox.Show("Hiba");
                }
            }
        }
    }
}
