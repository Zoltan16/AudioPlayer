﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Threading;

namespace AudioLejatszo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BindingList<string> _playlist = new BindingList<string>();
        MediaPlayer _mediaPlayer = new MediaPlayer();
        DispatcherTimer _mediaPlayerTimer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            Lista.ItemsSource = _playlist;
            _mediaPlayer.MediaOpened += _mediaPlayer_MediaOpened;
            _mediaPlayer.MediaEnded += _mediaPlayer_MediaEnded;
        }
        private void _mediaPlayer_MediaOpened(object sender, EventArgs e)
        {
            if (_mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                Csúszka.Maximum = _mediaPlayer.NaturalDuration.TimeSpan.TotalMilliseconds;
                _mediaPlayerTimer.Interval = TimeSpan.FromMilliseconds(200);
                _mediaPlayerTimer.Tick += UpdateTime;
                _mediaPlayerTimer.Start();
                Csúszka.IsEnabled = true;
            }
        }

        void UpdateTime(object sender, EventArgs e)
        {
            Csúszka.Value = _mediaPlayer.Position.TotalMilliseconds;
            if(_mediaPlayer.NaturalDuration.HasTimeSpan && !_mediaPlayer.IsMuted)
            Idő.Text = $"{_mediaPlayer.Position.ToString(@"m\:ss")}/{_mediaPlayer.NaturalDuration.TimeSpan.ToString(@"m\:ss")}";
            else
            Idő.Text = "0:00/0:00";
        }

        private void _mediaPlayer_MediaEnded(object sender, EventArgs e)
        {
            if (Lista.SelectedIndex == -1) return;

            if (Lista.SelectedIndex != Lista.Items.Count - 1)
            {
                Lista.SelectedIndex++;
                PlayCurrentSong();
            }
            else
            {
                Pause();
                Lista.SelectedIndex = -1;
                _mediaPlayer.Stop();
                Csúszka.IsEnabled = false;
            }
        }

        private void Mappa_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog fileDialog = new Microsoft.Win32.OpenFileDialog()
            {
                Multiselect = true,
                Filter = "Audio Files (*.mp3; *.flac; *.wav) |*.mp3;*.flac;*.wav"
            }; 

            if ((bool)fileDialog.ShowDialog())
            {
                fileDialog.FileNames.ToList().ForEach(x => 
                { 
                    _playlist.Add(x);
                });
                Lista.SelectedIndex = 0;
                Play();
            }
        }

        private void PlayStop_Click(object sender, RoutedEventArgs e)
        {
            if ((string)Lejátszás.Content == "Lejátszás" && _playlist.Count != 0)
            {
                Play();
            }
            else if ((string)Lejátszás.Content == "Megállítás")
            {
                Pause();
            }
        }

        private void Lista_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (Lista.SelectedIndex == -1) return;
            try
            {
                PlayCurrentSong();
            }
            catch(Exception)
            {
                System.Windows.MessageBox.Show("Nem lehet lejátszani a kiválasztott fájlt!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        void Play()
        {
            if (Lista.SelectedIndex == -1) return;

            Lejátszás.Content = "Megállítás";
            _mediaPlayer.Play();

            _mediaPlayer.IsMuted = false;
        }

        void Pause()
        {
            Lejátszás.Content = "Lejátszás";
            _mediaPlayer.Pause();
        }

        void PlayCurrentSong()
        {
            if (Lista.SelectedItem == null)
                return;

            _mediaPlayer.Open(new Uri((string)Lista.SelectedItem));
            Play();
            //Nem értem miért nem vált át a következő számra (ha várok az elindítás után 3 mp-et) amiután a végére tekerek az adott számnak. Egyébként meg ha gyorsan a végére tekerek (1-2 mp-el a vége előtt) elindul a következő szám. Mi lehet itt a probléma?
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            Pause();
            Lista.SelectedIndex = -1;
            _mediaPlayer.Stop();

            Idő.Text = "0:00/0:00";
            _mediaPlayer.IsMuted = true;
        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != 0)
                Lista.SelectedIndex--;
            PlayCurrentSong();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != Lista.Items.Count-1)
                Lista.SelectedIndex++;
            PlayCurrentSong();
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _mediaPlayer.Volume = e.NewValue;
        }

        private void Ment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lejatszasilista.Items.Clear();
                for (int i = 0; i < Lista.Items.Count; i++)
                {
                    Lejatszasilista.Items.Add(Lista.Items[i].ToString());
                }
            }
            catch (Exception o)
            {
                System.Windows.MessageBox.Show("Hiba");
            }
        }

        private void Csúszka_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _mediaPlayer.Position = TimeSpan.FromMilliseconds(e.NewValue);
        }

        private void Törlés_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != -1)
                _playlist.RemoveAt(Lista.SelectedIndex);

            Stop_Click(null, null);
        }
    }
}
